# Multilingual Project

This project is designed to support multiple languages, specifically Hindi, English, and Telugu. It provides a framework for internationalization (i18n) in a TypeScript application.

## Project Structure

```
multilingual-project
├── src
│   ├── app.ts                # Entry point of the application
│   ├── locales               # Contains translation files
│   │   ├── en.json          # English translations
│   │   ├── hi.json          # Hindi translations
│   │   └── te.json          # Telugu translations
│   └── utils                 # Utility functions for i18n
│       └── i18n.ts          # Functions for loading translations and switching languages
├── package.json              # npm configuration file
├── tsconfig.json             # TypeScript configuration file
└── README.md                 # Project documentation
```

## Installation

To get started with the project, clone the repository and install the dependencies:

```bash
git clone <repository-url>
cd multilingual-project
npm install
```

## Usage

To run the application, use the following command:

```bash
npm start
```

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License.