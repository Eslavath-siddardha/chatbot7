import fs from 'fs';
import path from 'path';

const localesPath = path.join(__dirname, '../locales');

let currentLanguage = 'en';
let translations = {};

const loadTranslations = (language) => {
    const filePath = path.join(localesPath, `${language}.json`);
    if (fs.existsSync(filePath)) {
        translations = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    } else {
        console.warn(`Translation file for language "${language}" not found.`);
    }
};

const switchLanguage = (language) => {
    currentLanguage = language;
    loadTranslations(language);
};

const translate = (key) => {
    return translations[key] || key;
};

loadTranslations(currentLanguage);

export { switchLanguage, translate };