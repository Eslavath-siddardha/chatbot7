import express from 'express';
import { loadTranslations, setLanguage } from './utils/i18n';

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to handle language selection
app.use((req, res, next) => {
    const lang = req.query.lang || 'en'; // Default to English
    setLanguage(lang);
    next();
});

// Load translations
loadTranslations();

// Sample route
app.get('/', (req, res) => {
    res.send('Welcome to the multilingual application!');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});